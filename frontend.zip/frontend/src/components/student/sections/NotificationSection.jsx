import React from "react";

const NotificationsSection = ({ notifications = [] }) => {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-6 py-4 border-b">
        <h3 className="text-xl font-semibold">Notifications</h3>
      </div>
      <div className="p-6">
        {notifications.map((notification) => (
          <div key={notification._id} className="mb-4 p-4 border rounded-lg">
            <p className="font-medium">{notification.message}</p>
            <p className="text-sm text-gray-500 mt-1">
              {new Date(notification.date).toLocaleString()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NotificationsSection;

import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  Box,
  Chip,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  Divider,
} from "@mui/material";
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
} from "@mui/lab";
import {
  Work,
  Assessment,
  Money,
  Business,
  Schedule,
} from "@mui/icons-material";

const ApplicationDetailView = ({ open, onClose, application }) => {
  const statusColors = {
    applied: "info",
    shortlisted: "warning",
    selected: "success",
    rejected: "error",
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle
        sx={{
          background: "linear-gradient(135deg, #2c3e50 0%, #3498db 100%)",
          color: "white",
        }}
      >
        Application Details
      </DialogTitle>
      <DialogContent sx={{ p: 4 }}>
        <Box className="space-y-4">
          {/* Job Details Section */}
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h5" color="primary" gutterBottom>
                {application?.job?.title}
              </Typography>
              <Box className="grid grid-cols-2 gap-4">
                <Box className="flex items-center gap-2">
                  <Business color="primary" />
                  <Typography>{application?.job?.company}</Typography>
                </Box>
                <Box className="flex items-center gap-2">
                  <Money color="primary" />
                  <Typography>₹{application?.job?.salary}/year</Typography>
                </Box>
                <Box className="flex items-center gap-2">
                  <Schedule color="primary" />
                  <Typography>
                    Applied on:{" "}
                    {new Date(application?.appliedAt).toLocaleDateString()}
                  </Typography>
                </Box>
                <Box className="flex items-center gap-2">
                  <Assessment color="primary" />
                  <Chip
                    label={application?.status}
                    color={statusColors[application?.status]}
                  />
                </Box>
              </Box>
            </CardContent>
          </Card>

          {/* Application Timeline */}
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" color="primary" gutterBottom>
                Application Timeline
              </Typography>
              <Timeline>
                {application?.timeline?.map((event, index) => (
                  <TimelineItem key={index}>
                    <TimelineSeparator>
                      <TimelineDot color={statusColors[event.status]} />
                      {index < application.timeline.length - 1 && (
                        <TimelineConnector />
                      )}
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="subtitle1">
                        {event.status}
                      </Typography>
                      <Typography variant="body2" color="textSecondary">
                        {new Date(event.date).toLocaleString()}
                      </Typography>
                      {event.remarks && (
                        <Typography variant="body2">{event.remarks}</Typography>
                      )}
                    </TimelineContent>
                  </TimelineItem>
                ))}
              </Timeline>
            </CardContent>
          </Card>

          {/* Round Status */}
          {application?.roundStatus?.length > 0 && (
            <Card elevation={2}>
              <CardContent>
                <Typography variant="h6" color="primary" gutterBottom>
                  Interview Rounds
                </Typography>
                <Box className="space-y-3">
                  {application.roundStatus.map((round, index) => (
                    <Box
                      key={index}
                      className="p-3 border rounded-lg"
                      sx={{ borderColor: "divider" }}
                    >
                      <Typography variant="subtitle1">{round.round}</Typography>
                      <Chip
                        label={round.status}
                        size="small"
                        color={statusColors[round.status]}
                        sx={{ my: 1 }}
                      />
                      {round.feedback && (
                        <Typography variant="body2">
                          {round.feedback}
                        </Typography>
                      )}
                    </Box>
                  ))}
                </Box>
              </CardContent>
            </Card>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default ApplicationDetailView;

import React from "react";
import {
  Paper,
  Typography,
  Grid,
  Button,
  Box,
  Chip,
  Card,
  CardContent,
  IconButton,
  Divider,
  Link,
} from "@mui/material";
import {
  School,
  Work,
  Code,
  Assignment,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";

const ProfileView = ({ student, onEdit }) => {
  return (
    <div className="space-y-6">
      {/* Basic Info Card */}
      <Paper elevation={2} sx={{ p: 3 }}>
        <Box className="flex justify-between items-start">
          <div>
            <Typography variant="h4">{student?.personalInfo?.name}</Typography>
            <Typography color="textSecondary">
              {student?.personalInfo?.department} • Batch of{" "}
              {student?.personalInfo?.batch}
            </Typography>
          </div>
          <Button variant="contained" startIcon={<EditIcon />} onClick={onEdit}>
            Edit Profile
          </Button>
        </Box>

        <Grid container spacing={4} className="mt-4">
          {/* Personal & Academic Info */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <School className="mr-2" />
                  Academic Information
                </Typography>
                <div className="space-y-2">
                  <div>
                    <Typography color="textSecondary" variant="subtitle2">
                      CGPA
                    </Typography>
                    <Typography variant="h5">
                      {student?.academics?.cgpa}
                    </Typography>
                  </div>
                  <div>
                    <Typography color="textSecondary" variant="subtitle2">
                      Class X
                    </Typography>
                    <Typography>{student?.academics?.tenthMarks}%</Typography>
                  </div>
                  <div>
                    <Typography color="textSecondary" variant="subtitle2">
                      Class XII
                    </Typography>
                    <Typography>{student?.academics?.twelfthMarks}%</Typography>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Grid>

          {/* Skills */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Code className="mr-2" />
                  Skills
                </Typography>
                <div className="flex flex-wrap gap-2">
                  {student?.skills?.map((skill, index) => (
                    <Chip
                      key={index}
                      label={skill}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Paper>

      {/* Projects Section */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            <Assignment className="mr-2" />
            Projects
          </Typography>
          <div className="space-y-4">
            {student?.projects?.map((project, index) => (
              <div key={index} className="border p-4 rounded">
                <div className="flex justify-between items-start">
                  <Typography variant="h6">{project.title}</Typography>
                  <div>
                    {project.links?.map((link, i) => (
                      <Link
                        key={i}
                        href={link.url}
                        target="_blank"
                        className="ml-2"
                      >
                        {link.type}
                      </Link>
                    ))}
                  </div>
                </div>
                <Typography color="textSecondary">
                  {project.description}
                </Typography>
                <div className="mt-2">
                  {project.technologies?.map((tech, i) => (
                    <Chip key={i} label={tech} size="small" className="mr-2" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Experience Section */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            <Work className="mr-2" />
            Experience
          </Typography>
          <div className="space-y-4">
            {student?.experience?.map((exp, index) => (
              <div key={index} className="border p-4 rounded">
                <Typography variant="h6">{exp.title}</Typography>
                <Typography color="textSecondary">
                  {exp.company} • {exp.duration}
                </Typography>
                <Typography className="mt-2">{exp.description}</Typography>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Education History */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            <School className="mr-2" />
            Education
          </Typography>
          <div className="space-y-4">
            {student?.education?.map((edu, index) => (
              <div key={index} className="border p-4 rounded">
                <Typography variant="h6">{edu.degree}</Typography>
                <Typography color="textSecondary">
                  {edu.institution} • {edu.year}
                </Typography>
                <Typography>Score: {edu.score}</Typography>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfileView;

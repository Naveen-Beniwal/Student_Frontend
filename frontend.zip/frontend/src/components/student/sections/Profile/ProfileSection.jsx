import React, { useState } from "react";
import ProfileView from "./ProfileView/ProfileView";
import ProfileEdit from "./ProfileEdit/ProfileEdit";
import axios from "axios";

const ProfileSection = ({ student, onProfileUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);

  const handleUpdate = async (updatedData) => {
    try {
      const response = await axios.put(
        `/api/v1/student/profile/${student._id}`,
        updatedData
      );
      if (response.data.statusCode === 200) {
        onProfileUpdate(response.data.data);
        setIsEditing(false);
      }
    } catch (error) {
      throw new Error(error.response?.data?.message || "Update failed");
    }
  };

  return isEditing ? (
    <ProfileEdit
      student={student}
      onUpdate={handleUpdate}
      onCancel={() => setIsEditing(false)}
    />
  ) : (
    <ProfileView student={student} onEdit={() => setIsEditing(true)} />
  );
};

export default ProfileSection;

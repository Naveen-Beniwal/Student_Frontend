import React, { useState } from "react";
import { Paper, Box, Button, Alert, Snackbar } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import PersonalInfoEdit from "./PersonalInfoEdit";
import SkillsEdit from "./SkillsEdit";
import ProjectsEdit from "./ProjectsEdit";
import ExperienceEdit from "./ExperienceEdit";
import EducationEdit from "./EducationEdit";
import AcademicsEdit from "./AcademicsEdit";
const ProfileEdit = ({ student, onCancel }) => {
  const navigate = useNavigate();
  // Update the formData initialization
  const [formData, setFormData] = useState({
    personalInfo: student?.personalInfo || {},
    academics: student?.academics || {
      cgpa: "",
      tenthMarks: "",
      twelfthMarks: "",
    },
    skills: student?.skills || [],
    projects: student?.projects || [],
    experience: student?.experience || [],
    education: student?.education || [],
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await axios.put(
        `/api/v1/student/profile/${student._id}`,
        formData
      );

      if (response.data.statusCode === 200) {
        setSuccess(true);
        setTimeout(() => {
          navigate(`/student-dashboard/${student._id}`);
        }, 1500);
      }
    } catch (err) {
      console.error("Update error:", err);
      setError(err.response?.data?.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert severity="error" onClose={() => setError("")}>
          {error}
        </Alert>
      )}

      <Snackbar
        open={success}
        autoHideDuration={3000}
        message="Profile updated successfully"
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      />

      <Paper elevation={2} className="p-6">
        <Box className="flex justify-between items-center mb-6">
          <Box>
            <Button
              variant="outlined"
              onClick={onCancel}
              disabled={loading}
              className="mr-2"
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              type="submit"
              disabled={loading}
              color="primary"
            >
              {loading ? "Updating..." : "Save Changes"}
            </Button>
          </Box>
        </Box>

        <div className="space-y-6">
          <PersonalInfoEdit
            data={formData.personalInfo}
            isLocked={student?.personalInfo?.isLocked}
            onChange={(personalInfo) =>
              setFormData((prev) => ({
                ...prev,
                personalInfo,
              }))
            }
          />

          <AcademicsEdit
            data={formData.academics}
            isLocked={student?.academics?.isLocked}
            onChange={(academics) =>
              setFormData((prev) => ({
                ...prev,
                academics,
              }))
            }
          />

          <SkillsEdit
            skills={formData.skills}
            onSkillsChange={(skills) =>
              setFormData((prev) => ({
                ...prev,
                skills,
              }))
            }
          />

          <ProjectsEdit
            projects={formData.projects}
            onProjectsChange={(projects) =>
              setFormData((prev) => ({
                ...prev,
                projects,
              }))
            }
          />

          <ExperienceEdit
            experience={formData.experience}
            onExperienceChange={(experience) =>
              setFormData((prev) => ({
                ...prev,
                experience,
              }))
            }
          />

          <EducationEdit
            education={formData.education}
            onEducationChange={(education) =>
              setFormData((prev) => ({
                ...prev,
                education,
              }))
            }
          />
        </div>
      </Paper>
    </form>
  );
};

export default ProfileEdit;

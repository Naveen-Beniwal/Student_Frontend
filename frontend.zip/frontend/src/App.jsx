import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import JNFForm from "./components/JNF/JNFForm";
import Home from "./pages/HomePage";
import Login from "./components/auth/Login";
import Signup from "./components/auth/Signup";
import StudentDashboard from "./components/student/StudentDashboard";
const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/jnf-form" element={<JNFForm />} />
        <Route path="/student-dashboard/:id" element={<StudentDashboard />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
